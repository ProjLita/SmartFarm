import flet as ft

def smartfarm1(router_data=None):
    page = router_data.page
    is_dark = page.theme_mode == ft.ThemeMode.DARK

    # Cores
    bg_color = ft.Colors.BLACK if is_dark else ft.Colors.WHITE
    text_color = ft.Colors.WHITE if is_dark else ft.Colors.BLACK
    border_color = ft.Colors.GREY_700 if is_dark else ft.Colors.GREY_300

    # Card do gráfico
    chart_card = ft.Container(
        bgcolor=bg_color,
        padding=20,
        border_radius=15,
        shadow=ft.BoxShadow(
            color=ft.Colors.with_opacity(0.2, ft.Colors.BLACK) if not is_dark else ft.Colors.with_opacity(0.3, ft.Colors.WHITE),
            blur_radius=10,
            spread_radius=2,
            offset=ft.Offset(2, 4)
        ),
        content=ft.Column(
            spacing=10,
            controls=[
                ft.Text(
                    "Métricas da SmartFarm",
                    size=22,
                    weight=ft.FontWeight.BOLD,
                    color=text_color,
                    text_align=ft.TextAlign.CENTER
                ),
                ft.BarChart(
                    bar_groups=[
                        ft.BarChartGroup(x=0, bar_rods=[ft.BarChartRod(to_y=2, color=ft.Colors.GREEN_ACCENT, width=30)]),
                        ft.BarChartGroup(x=1, bar_rods=[ft.BarChartRod(to_y=3, color=ft.Colors.LIGHT_GREEN, width=30)]),
                        ft.BarChartGroup(x=2, bar_rods=[ft.BarChartRod(to_y=4, color=ft.Colors.LIME, width=30)]),
                        ft.BarChartGroup(x=3, bar_rods=[ft.BarChartRod(to_y=6, color=ft.Colors.YELLOW, width=30)]),
                        ft.BarChartGroup(x=4, bar_rods=[ft.BarChartRod(to_y=7, color=ft.Colors.ORANGE, width=30)]),
                        ft.BarChartGroup(x=5, bar_rods=[ft.BarChartRod(to_y=8, color=ft.Colors.AMBER, width=30)]),
                    ],
                    border=ft.border.all(1, border_color),
                    left_axis=ft.ChartAxis(
                        labels_size=30,
                        title=ft.Text("Crescimento", size=12, weight=ft.FontWeight.BOLD, color=text_color),
                    ),
                    bottom_axis=ft.ChartAxis(
                        labels=[
                            ft.ChartAxisLabel(value=0, label=ft.Text("Jan", color=text_color)),
                            ft.ChartAxisLabel(value=1, label=ft.Text("Fev", color=text_color)),
                            ft.ChartAxisLabel(value=2, label=ft.Text("Mar", color=text_color)),
                            ft.ChartAxisLabel(value=3, label=ft.Text("Abr", color=text_color)),
                            ft.ChartAxisLabel(value=4, label=ft.Text("Mai", color=text_color)),
                            ft.ChartAxisLabel(value=5, label=ft.Text("Jun", color=text_color)),
                        ],
                        labels_size=30,
                    ),
                    max_y=10,
                    animate=True,
                    interactive=False,
                )
            ]
        )
    )

    back_button = ft.IconButton(icon=ft.Icons.ARROW_BACK, on_click=lambda e: page.go("/"))

    minha_plant= ft.Container(
                    content=ft.Row(
                        controls=[
                            ft.Text("Morango", weight=ft.FontWeight.BOLD),
                            ft.Container(
                                width=1,
                                height=70,
                                bgcolor=ft.Colors.GREY,
                            ),
                            ft.Icon(
                                name=ft.Icons.KEYBOARD_ARROW_RIGHT,
                                size=30
                            )
                        ],
                        alignment=ft.MainAxisAlignment.SPACE_EVENLY,
                        spacing=50
                    ),
                    expand=True,
                    height=120,
                    border=ft.border.all(2, ft.Colors.GREY_200),
                    border_radius=10,
                    alignment=ft.alignment.center,
                    on_click=lambda e: e.page.go("/plantacao")
                )

    
    return ft.Column(
        spacing=30,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        controls=[
            ft.Row(
                controls=[
                back_button,
                ft.Text(
                "SmartFarm 1 - Visão Geral",
                size=24,
                weight=ft.FontWeight.BOLD,
                text_align=ft.TextAlign.CENTER
                    )
                ],
            ),
            chart_card,
            minha_plant       
        ],
        alignment=ft.MainAxisAlignment.CENTER
    )